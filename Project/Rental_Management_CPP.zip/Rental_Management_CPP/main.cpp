#include "fileoperation.h"

using namespace std;

int main()
{
    FileOperation *file = nullptr;
    file->readVehicleData();

    return 0;
}
